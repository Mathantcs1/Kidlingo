"""Ground truth with plain SQL, no AI: October 2026, delivered orders. Revenue = qty x the product's current price."""
import sqlite3
c = sqlite3.connect('shop.db'); W = "o.status='delivered' and o.ordered_at like '2026-10-%'"
print('Oct 2026 revenue:', c.execute(f"select round(sum(o.qty*p.price),2) from orders o join products p on p.id=o.product_id where {W}").fetchone()[0])
print('Top products:', c.execute(f"select p.name, round(sum(o.qty*p.price),2) from orders o join products p on p.id=o.product_id where {W} group by p.name order by 2 desc limit 2").fetchall())
print('Top city:', c.execute(f"select cu.city, round(sum(o.qty*p.price),2) from orders o join products p on p.id=o.product_id join customers cu on cu.id=o.customer_id where {W} group by cu.city order by 2 desc limit 1").fetchall())
print('Cancelled orders:', c.execute("select count(*) from orders where status='cancelled'").fetchone()[0])
