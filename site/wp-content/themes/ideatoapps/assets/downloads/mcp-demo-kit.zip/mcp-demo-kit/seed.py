"""Builds shop.db: 40 customers, 8 products, 500 orders. Deterministic sample data (fixed seed + constructed so the October 2026 figures repeat exactly).
The orders table has no price column on purpose: revenue = qty x the product's current price."""
import itertools, random, sqlite3, os
R = random.Random(2026)
CITIES = ['Boston', 'Seattle', 'Austin', 'Denver', 'Chicago', 'Portland', 'Atlanta', 'Miami']
BASE = [(1, '27in Monitor', 249.00), (2, 'Noise-Cancel Headphones', 179.00), (3, 'Webcam 4K', 129.00)]
OPTS = {4: ('Standing Desk', [399.99, 349.00, 379.95]), 5: ('Mechanical Keyboard', [129.99, 119.00, 139.95]), 6: ('USB-C Dock', [149.95, 139.99, 159.00]),
        7: ('Wireless Mouse', [49.99, 39.99, 59.95]), 8: ('Laptop Stand', [59.50, 49.95, 69.99])}
TOP = {1: 21, 2: 21, 3: 26}; TOPREV = 21 * 24900 + 21 * 17900 + 26 * 12900; OTHER_REV = 1876470 - TOPREV; sol = None
for ps in itertools.product(*[range(3)] * 5):                     # pick price points until an exact unit mix exists (deterministic order)
    pr = {i: round(OPTS[i][1][ps[i - 4]] * 100) for i in OPTS}
    for N in range(38, 47):
        for d in range(0, 9):
            for k in range(0, 26):
                for u in range(0, 23):
                    M = N - d - k - u
                    if M < 0: continue
                    rem = OTHER_REV - pr[4] * d - pr[5] * k - pr[6] * u
                    if (rem - pr[7] * M) % (pr[8] - pr[7]) == 0:
                        sx = (rem - pr[7] * M) // (pr[8] - pr[7]); mx = M - sx
                        if sx >= 0 and mx >= 0 and all(pr[i] * x < 335400 for i, x in zip((4, 5, 6, 7, 8), (d, k, u, mx, sx))) and N - 38 <= min(k, u, mx, sx) // 2 * 4:
                            sol = (ps, pr, (d, k, u, mx, sx)); break
                if sol: break
            if sol: break
        if sol: break
    if sol: break
assert sol, 'no unit mix found'
ps, pr, cnt = sol
PRODUCTS = BASE + [(i, OPTS[i][0], OPTS[i][1][ps[i - 4] ]) for i in range(4, 9)]
P = {i: round(p * 100) for i, _, p in PRODUCTS}
units = dict(TOP); units.update({4 + j: cnt[j] for j in range(5)})
lines = []
for pid, n in units.items(): lines += [(pid, 1)] * n
while len(lines) > 106:                                           # merge same-product pairs into qty-2 orders until exactly 106 orders
    pid = next(p for p in (5, 6, 7, 8, 4) if sum(1 for l in lines if l == (p, 1)) >= 2)
    i = lines.index((pid, 1)); lines.pop(i); j = lines.index((pid, 1)); lines[j] = (pid, 2)
assert len(lines) == 106
tot = [P[p] * q for p, q in lines]
# --- Boston subset sum: exactly 446946 cents, found by bitset DP
TARGET = 446946; reach = {0: -1}; bits = 1; order = []
dp = [None] * (TARGET + 1); dp[0] = ()
for n, v in enumerate(tot):
    for s in range(TARGET - v, -1, -1):
        if dp[s] is not None and dp[s + v] is None: dp[s + v] = dp[s] + (n,)
assert dp[TARGET] is not None, 'no Boston subset'
boston = set(dp[TARGET]); rest = [n for n in range(106) if n not in boston]
# --- build the database
db = 'shop.db'
if os.path.exists(db): os.remove(db)
c = sqlite3.connect(db); c.executescript('create table customers(id integer primary key, name text, city text); create table products(id integer primary key, name text, price real); create table orders(id integer primary key, customer_id integer, product_id integer, qty integer, status text, ordered_at text);')
FIRST = ['Ava', 'Noah', 'Mia', 'Liam', 'Zoe', 'Ethan', 'Ivy', 'Owen', 'Ruby', 'Leo']; LAST = ['Hart', 'Nguyen', 'Patel', 'Reyes', 'Kim', 'Brooks', 'Silva', 'Novak']
cust = [(i + 1, f'{FIRST[i % 10]} {LAST[(i * 3) % 8]}', CITIES[i // 5]) for i in range(40)]                 # 5 customers per city
c.executemany('insert into customers values (?,?,?)', cust); c.executemany('insert into products values (?,?,?)', [(i, n, p) for i, n, p in PRODUCTS])
by_city = {ct: [x[0] for x in cust if x[2] == ct] for ct in CITIES}; others = [ct for ct in CITIES if ct != 'Boston']
rows = []; oid = 0
def add(cid, pid, q, status, day): 
    global oid; oid += 1; rows.append((oid, cid, pid, q, status, f'2026-{day[0]:02d}-{day[1]:02d}'))
for n in sorted(boston): add(R.choice(by_city['Boston']), *lines[n], 'delivered', (10, R.randint(1, 31)))
city_cap = {ct: 0 for ct in others}
for n in rest:                                                    # spread the other Oct orders so Boston stays the top city
    for _ in range(50):
        ct = R.choice(others)
        if city_cap[ct] + tot[n] < 440000: city_cap[ct] += tot[n]; add(R.choice(by_city[ct]), *lines[n], 'delivered', (10, R.randint(1, 31))); break
    else: raise SystemExit('city cap')
while len(rows) < 106: raise SystemExit('rows')
# 394 other orders: 40 cancelled (any month), the rest delivered in Sep, shipped/pending in Nov or late Oct (never delivered in Oct)
for i in range(394):
    pid = R.randint(1, 8); q = R.choice([1, 1, 1, 2]); cid = R.randint(1, 40)
    if i < 40: add(cid, pid, q, 'cancelled', (R.choice([9, 10, 11]), R.randint(1, 28)))
    elif i < 200: add(cid, pid, q, 'delivered', (9, R.randint(1, 30)))
    elif i < 260: add(cid, pid, q, 'delivered', (11, R.randint(1, 10)))
    elif i < 340: add(cid, pid, q, 'shipped', (11, R.randint(5, 20)))
    else: add(cid, pid, q, 'pending', (11, R.randint(15, 24)))
R.shuffle(rows); rows = [(i + 1,) + r[1:] for i, r in enumerate(rows)]
c.executemany('insert into orders values (?,?,?,?,?,?)', rows); c.commit()
print('shop.db ready:', {t: c.execute(f'select count(*) from {t}').fetchone()[0] for t in ('customers', 'products', 'orders')})
