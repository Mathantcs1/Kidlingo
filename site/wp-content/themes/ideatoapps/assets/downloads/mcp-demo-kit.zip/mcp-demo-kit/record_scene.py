"""Record a REAL shell command: timestamped output lines -> recordings/<run>.json  {cmd, lines:[{t,s}], end}.   usage: python3 record_scene.py <run> '<shell command>' [cwd]"""
import json, os, subprocess, sys, time, threading
run, cmd = sys.argv[1], sys.argv[2]; cwd = sys.argv[3] if len(sys.argv) > 3 else os.getcwd(); os.makedirs('recordings', exist_ok=True)
t0 = time.time(); lines = []
p = subprocess.Popen(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, executable='/bin/bash')
for l in p.stdout: lines.append({'t': round(time.time() - t0, 2), 's': l.rstrip('\n')})
p.wait(); json.dump({'cmd': cmd, 'lines': lines, 'end': round(time.time() - t0, 2), 'code': p.returncode}, open(f'recordings/{run}.json', 'w'), indent=1)
print(run, 'rc', p.returncode, len(lines), 'lines', round(time.time() - t0, 1), 's')
