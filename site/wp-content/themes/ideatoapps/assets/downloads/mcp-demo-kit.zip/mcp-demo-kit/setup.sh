#!/usr/bin/env bash
# One-time setup: virtual environment, the official MCP Python SDK, and the sample store database.
set -e
uv venv -q .venv
uv pip install -q --python .venv/bin/python "mcp[cli]==2.3.0"
.venv/bin/python seed.py
