"""Run one real Claude Code question and summarise the real stream: tool calls (name, input), final answer, duration.
usage: python3 ask.py <name> "<question>" [--server]    (--server connects the store MCP server; without it Claude has NO tools and NO data)
Writes real-outputs/<name>.jsonl (raw stream) and real-outputs/<name>.json (summary used by the video)."""
import json, subprocess, sys, time, os
name, q = sys.argv[1], sys.argv[2]; srv = '--server' in sys.argv
os.makedirs('real-outputs', exist_ok=True)
cmd = ['claude', '-p', q, '--output-format', 'stream-json', '--verbose', '--tools', '', '--max-turns', '12']
if srv: cmd += ['--mcp-config', '.mcp.json', '--strict-mcp-config', '--allowedTools', 'mcp__store']
else: cmd += ['--strict-mcp-config']
t0 = time.time(); p = subprocess.run(cmd, capture_output=True, text=True, cwd=os.getcwd() if srv else 'empty', timeout=300); dt = time.time() - t0
open(f'real-outputs/{name}.jsonl', 'w').write(p.stdout)
calls, result, cost, dur = [], '', None, None
for l in p.stdout.splitlines():
    try: e = json.loads(l)
    except Exception: continue
    if e.get('type') == 'assistant':
        for b in e['message'].get('content', []):
            if b.get('type') == 'tool_use': calls.append({'tool': b['name'].replace('mcp__store__', ''), 'input': b['input'], 't': round(time.time() - t0, 1)})
    if e.get('type') == 'result': result = e.get('result', ''); dur = e.get('duration_ms'); cost = e.get('total_cost_usd')
json.dump({'name': name, 'question': q, 'server': srv, 'wall_s': round(dt, 1), 'duration_ms': dur, 'calls': calls, 'answer': result}, open(f'real-outputs/{name}.json', 'w'), indent=1)
print(f'{name}: wall {dt:.1f}s, claude duration {dur} ms, {len(calls)} tool calls: {[c["tool"] for c in calls]}'); print('ANSWER:', result[:900]); print('stderr:', p.stderr[:300])
