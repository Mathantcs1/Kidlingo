"""A tiny stand-in for an AI app: sends the raw JSON-RPC messages to server.py over stdio and prints each request (>>) and response (<<)."""
import json, subprocess, sys, time
p = subprocess.Popen(['.venv/bin/python', 'server.py'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
def send(m, wait=True):
    print('>>', json.dumps(m, separators=(',', ':')), flush=True); p.stdin.write(json.dumps(m) + '\n'); p.stdin.flush()
    if wait: print('<<', p.stdout.readline().strip(), flush=True)
send({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2025-06-18', 'capabilities': {}, 'clientInfo': {'name': 'raw', 'version': '0'}}})
send({'jsonrpc': '2.0', 'method': 'notifications/initialized'}, wait=False); time.sleep(0.5)
send({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'run_sql', 'arguments': {'query': 'select count(*) from orders'}}})
p.stdin.close(); p.wait(timeout=10)
