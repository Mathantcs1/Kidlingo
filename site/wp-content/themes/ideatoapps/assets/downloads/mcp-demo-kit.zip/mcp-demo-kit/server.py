import sqlite3
from mcp.server import MCPServer

mcp = MCPServer("store")

# Safety layer 2: the connection itself is read-only, so even a bad query cannot change data.
def db() -> sqlite3.Connection:
    """Open shop.db in read-only mode."""
    return sqlite3.connect("file:shop.db?mode=ro", uri=True)

@mcp.tool()
def list_tables() -> str:
    """List the tables in the store database."""
    with db() as c:
        return "\n".join(r[0] for r in c.execute("select name from sqlite_master where type='table'"))

@mcp.tool()
def describe_table(table: str) -> str:
    """Show the columns of one table. Call this before writing SQL."""
    with db() as c:
        return "\n".join(f"{n} {t}" for n, t in c.execute("select name, type from pragma_table_info(?)", (table,)))

@mcp.tool()
def run_sql(query: str) -> str:
    """Run one read-only SQL SELECT query and return the rows."""
    if not query.strip().lower().startswith("select"):  # Safety layer 1: only SELECT gets through
        return "Blocked: this server only allows SELECT queries."
    with db() as c:
        return "\n".join(" | ".join(map(str, row)) for row in c.execute(query))

# A resource is data to read; a prompt is a ready-made template.
@mcp.resource("store://about")
def about() -> str:
    """What is in this database."""
    return "A sample online store: customers, products and orders. Orders have no price column."

@mcp.prompt()
def monthly_report(month: str) -> str:
    """A ready-made request for a monthly sales report."""
    return f"Give me the {month} sales report: total revenue, top product and top city, delivered orders only."

if __name__ == "__main__":
    mcp.run()
